import { useState } from "react"

export default function Contador() {


    const incrementar = () => {
        setState(state + 1)
    }
    const descrementar = () => {
        setState(state - 1)
    }


    const [state, setState] = useState(0)
    return (
        <div>
            <p>{state}</p>
            <button onClick={incrementar
            } >+</button>
            <button onClick={descrementar} disabled={state <= 0}>-</button>
        </div>
    )
}