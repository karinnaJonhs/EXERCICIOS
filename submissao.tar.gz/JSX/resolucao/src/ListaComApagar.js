import { useState } from "react";

export function ListaComApagar(item){
 const [state, setState] = useState("")
}