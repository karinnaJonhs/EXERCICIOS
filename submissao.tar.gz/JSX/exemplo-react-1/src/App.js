import React from 'react';
import Marquee from 'react-fast-marquee';
import './App.css';


function App() {

  const user = { primeiro: "Marta", segundo: "Maria" }
  return (


    <div className="App-header">

      <div><h1 className='titulo'>{user.primeiro} {user.segundo}</h1></div>


    </div>

  );
}

function Soma({a,b}){
 const ({a} + {b} = {a+b});
}


export default App;
