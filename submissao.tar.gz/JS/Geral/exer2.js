function perimetroQuadrado(lado) {

    return lado *= 4
}

console.log(perimetroQuadrado(2))
console.log(perimetroQuadrado(3))