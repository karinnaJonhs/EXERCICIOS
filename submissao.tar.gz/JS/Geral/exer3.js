function potenciaGrande(x, n) {
    return BigInt(x) ** BigInt(n)
}
console.log(potenciaGrande(10, 3000))