# Thitulu

---

hoje não é **amanhã**

---

Desde quando é assim?

---

Então no fundo só fechas então?

---

A vida não interessa e ninguém merece a sua confiança :(