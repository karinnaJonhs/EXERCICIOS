const numeros = [1, 2, 3, 4, 5]

const total = numeros.reduce((acc, item) => acc + item)

console.log(total)