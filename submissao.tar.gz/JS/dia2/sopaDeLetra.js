function palavraExisteEmSopaDeLetras(strarray, palavra) {

    // comparar elementos para ver se a palavra existe no array
/*

    while (j >= 0) {

        for (let i = 0; i < array.length; i++) {
            if (strarray.includes(word)) {
                return true
            }
            return false

        }
        j--
    }

    */
}

function verificaHorizontais(){

    
}

console.log(palavraExisteEmSopaDeLetras([
    "baa",
    "bga", if (word[j] === strarray[i ][k]) j++
    "ova"], "tsw"))