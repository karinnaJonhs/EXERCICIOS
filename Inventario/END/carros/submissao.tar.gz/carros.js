const express = require('express')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())
app.listen(port, () => {
    console.log(port + ": Alô, quem tá falando?")
})

app.get('/api/carros/:marca', (req, res) => {
    const { marca } = req.params
    if (marca == "mercedes") {
        res.status(200).json({ existe: true })
    } else if (marca == "audi") {
        res.status(200).json({ existe: true })
    } else {
        res.status(404).json({ existe: false })
    }
})
