const express = require('express')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())
app.listen(port, () => {
    console.log(port + ": Alõ, quem tá falando?")
})

let contas = []

function validateEmail(email) {
    // Esta expressão regular não garante que email existe, nem que é válido
    // No entanto deverá funcionar para a maior parte dos emails que seja necessário validar.
    const EMAIL_REGEX = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return EMAIL_REGEX.test(email)
}

function checkPasswordStrength(password) {
    if (password.length < 8) return 0;
    const regexes = [
        /[a-z]/,
        /[A-Z]/,
        /[0-9]/,
        /[~!@#$%^&*)(+=._-]/
    ]
    return regexes
        .map(re => re.test(password))
        .reduce((score, t) => t ? score + 1 : score, 0)
}


function validaDados(emailIp, passwordIp, passwordConfirmationIp, acceptTermsIp) {

    let errors = {}

    //EMAIL
    if (!emailIp || emailIp.length === 0) {
        errors.email = "Por favor introduza o seu endereço de email."
    } else if (!validateEmail(emailIp)) {
        errors.email = "Por favor introduza um endereço de email válido."
    } else if (contas.some(ele => ele.email == emailIp)) {
        errors.email = "O endereço introduzido já está registado."
    }

    //SENHA
    if (!passwordIp || passwordIp.length === 0) {
        errors.password = "Por favor introduza a sua password."
    } else if (passwordIp.length < 8) {
        errors.password = "A sua password deve ter no mínimo 8 caracteres."
    } else if (checkPasswordStrength(passwordIp) < 4) {
        errors.password = "A sua password deve ter pelo menos um número, uma mínuscula, uma maiúscula e um símbolo."
    }

    //Confirmação Da Senha
    if (passwordConfirmationIp == "") {
        errors.passwordConfirmation = "Por favor introduza novamente a sua password."
    } else if (passwordConfirmationIp != passwordIp) {
        errors.passwordConfirmation = "As passwords não coincidem."
    }



    //TERMOS DE USO
    if (!acceptTermsIp) {
        errors.acceptsTerms = "Tem de aceitar os termos e condições para criar a sua conta."
    }

    return errors
}



//corpo email
app.post('/signup', (req, res) => {
    const { email, password, passwordConfirmation, acceptsTerms, acceptsCommunications } = req.body

    //validar se são reais 
    const errors = validaDados(email, password, passwordConfirmation, acceptsTerms)
    if (Object.keys(errors).length > 0) {
        res.status(400).json({
            message: "Os dados introduzidos não são válidos.",
            errors: errors
        })
    } else {
        contas.push(req.body)
        res.status(201).json(
            { message: "Utilizador Criado com Sucesso!" }
        )
    }
})

function generateToken(email) {
    return email
        .split('')
        .map((e, i) => String.fromCharCode(e.charCodeAt(0) + (i % 4 + 1) * 2))
        .join('')
}

let sessoes = []

app.post('/login', (req, res) => {
    const { email, password } = req.body
    const user = contas.find(conta => conta.email === email)



    if (!user) {
        res.status(404).json({ message: "O utilizador não foi encontrado!" })
    } else {
        if (user.password !== password) {
            res.status(401).json({ message: "A password introduzida é inválida!" })
        } else {
            const token = generateToken(email)
            sessoes.push({ token, email })
            res.status(200).json({ token })
        }
    }

})

app.get('/user', (req, res) => {
    const token = req.header("authorization")

    if (token === undefined) {
        res.status(401).json({ message: "Não foi enviado o token de autenticação!" })
    } else if (sessoes.find(user => user.token === token) == undefined) {
        res.status(403).json({ message: "Não existe nenhuma sessão com o token indicado!" })
    } else {
        const sessao = sessoes.find(s => s.token === token)
        const user = contas.find(c => c.email === sessao.email)
        res.status(200).json({
            email: user.email,
            acceptsTerms: user.acceptsTerms,
            acceptsCommunications: user.acceptsCommunications
        })
    }
})
