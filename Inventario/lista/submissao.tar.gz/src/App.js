import logo from './logo.svg';
import './App.css';
import DataInput from './DataInput';
import Lista from './Lista';

function App() {
  return (
    <div className="App">
      <Lista/>
    </div>
  );
}

export default App;
