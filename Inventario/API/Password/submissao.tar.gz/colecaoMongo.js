const express = require('express')
const { ObjectId } = require('mongodb')
const { insertColection, getCollectionById, getCollectionBy_id } = require('./data/colection')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())

app.listen(port, () => {
    console.log("ESSA EH A PORTA CERTA! (ou nao)")
})

app.get("/users", (req, res) => {
    const users = findAllUsers()

    res.status(200).json(users)
})

app.get('/api/colecao/:id', async (req, res) => {
    const id = req.params
    const ele = await getCollectionBy_id(new ObjectId(id))
    if (!ele) {
        return res.sendStatus(404)
    }
    res.status(200).json(ele)

})

app.patch('/api/colecao/:id', (req, res) => {
    const id = req.params
})

app.post('/api/colecao', async (req, res) => {
    const coisa = req.body
    const ele = await getCollectionById(coisa.id)
    if (!ele) {
        const _id = await insertColection(coisa)
        return res.status(200).json({ _id })
    }
    res.sendStatus(409)

})