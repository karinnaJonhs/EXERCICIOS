const express = require('express')
const app = express()
app.use(express.json())
const port = process.env.PORT ?? 3000
app.listen(port, () => {
    console.log("COISAS ESTÃO ACONTECENDO NO PLANETA " + port)
})

function validacaoSenha(pass, conPass) {
    let forca = 0
    const MAI = "abcdefghijklmnopqrstuvwxyz"
    const ORES = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const nums = "0987654321"
    if (pass == conPass) {
        forca++

        if (pass.split("").some(l => MAI.includes(l))) {
            forca++
        }

        if (pass.split("").some(l => ORES.includes(l))) {
            forca++
        }

        if (pass.length >= 8) {
            forca++
        }

        if (pass.split("").some(l => nums.includes(l))) {
            forca++
        }


    }
    return forca

}


app.patch('/api/auth/password', (req, res) => {
    const { password, confirmacaoPassword } = req.body

    if (password != confirmacaoPassword) {
        res.status(200).json({ forca: 0, valida: false })
    } else if (validacaoSenha(password, confirmacaoPassword) > 3) {
        res.status(200).json({ forca: validacaoSenha(password, confirmacaoPassword), valida: true })
    } else if (validacaoSenha(password, confirmacaoPassword) <= 3) {
        res.status(200).json({ forca: validacaoSenha(password, confirmacaoPassword), valida: false })
    }

})