async function obtemDaColecao(id) {
    const stuff = await getCollectionBy_id(id)
    return stuff
}


