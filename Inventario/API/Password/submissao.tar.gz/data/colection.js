const { application } = require("express")
const { ObjectId } = require("mongodb")

const { getMongoCollection } = require("./mongodb")

const DB_NAME = "ColecaoMb"
const COLLECTION_NAME = "colection"

async function getObjetoById(objId) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return (await collection.findOne({ _id: objId }))
}
async function insertColection(data) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return (await collection.findOne(data)).insertedId
}
async function getCollectionBy_id(_id) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return (await collection.findOne({ _id }))
}
async function getCollectionById(id) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return (await collection.findOne({ id }))
}

module.exports = {
    insertColection,
    getCollectionById,
    getCollectionBy_id
}