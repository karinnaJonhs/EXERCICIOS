const express = require('express')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())

app.listen(port, () => {
    console.log(port + ": Alô, quem tá falando?")
})

let strings = [
    /*
    recebe strings, ex: "sua mae", "sopa", "suco detox"
    */
]

//RETORNAR A STRING UNIDA EM CamelCase
function capitalismo(str) {
    let n = []
    for (let i = 0; i < str.length; i++) {
        n.push(str[i][0].toUpperCase() + str[i].substr(1))
    }
    return n.join("")
}

app.patch('/api/strings', (req, res) => {
    if (req.body.strings.length == 0) {
        res.sendStatus(404)
    }
    res.status(200).json({ CamelCase: capitalismo(req.body.strings) })
})