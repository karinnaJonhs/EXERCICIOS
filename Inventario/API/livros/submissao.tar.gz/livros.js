const express = require('express')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())
app.listen(port, () => {
    console.log("aquela porta lá! 3 e alguma coisa...")
})

const livros = [
    {
        "id": "lusiadas",
        "nome": "Os Lusíadas",
        "ano": 1572,
        "author": "Luís Vaz de Camões"
    },
    {
        "id": "maias",
        "nome": "Os Maias",
        "ano": 1888,
        "author": "Eça de Queiroz"
    },
    {
        "id": "desassossego",
        "nome": "O Livro do Desassossego",
        "ano": 1982,
        "author": "Bernardo Soares (Fernando Pessoa)"
    },
    {
        "id": "mensagem",
        "nome": "Mensagem",
        "ano": 1934,
        "author": "Fernando Pessoa"
    }
]

app.get('/api/livros/:id', (req, res) => {
    const { id } = req.params

    const livro = livros.find(livro => livro.id === id)


    if (!livro) {
        res.sendStatus(404)
    } else {
        res.status(200).json({ livro })
    }

})