const { ObjectId } = require("mongodb")
const { generateToken } = require("../services/common")
const { getMongoCollection } = require("./mongodb")

const DB_NAME = "UsersMongoDB"
const COLLECTION_NAME = "users"

async function getUserByEmail(userEmail) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return await collection.findOne({ email: userEmail })

}
async function getUserById(userId) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return await collection.findOne({ _id: ObjectId(userId) })

}

async function checkPasswordIgual(email, password) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const resultado = await collection.findOne({
        $and:
            [{ email, password }]
    })
    return resultado
}


async function addUser(user) {

    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return (await collection.insertOne(user)).insertedId

}

async function checkIfEmailExists(userEmail) {

    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const a = await collection.findOne({ email: userEmail })
    return a
}



module.exports = {
    getUserByEmail,
    addUser,
    checkIfEmailExists,
    getUserById,
    checkPasswordIgual
}