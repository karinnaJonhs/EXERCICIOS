const express = require('express')
const app = express()
// const PORT = 3000 // nao eh obrigatorio
app.listen(3000, () => {
    console.log("À escuta em https://localhost:3000")
}) //OBRIGATÓRIO

app.get("/nome/lindademais", (req, res) => {
    //req.body acede ao corpo
    //req.params acede aos parametros
    res.send(`Olá, ${req.query.nome ?? `linda.`}`)
})
