const express = require('express')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())
app.listen(port, () => {
    console.log(port + ": Alô!! Quem tá falando?")
})

const dados = []

app.get('/api/colecao/:id', (req, res) => {
    const id = req.params
    if (id == undefined) {
        res.sendStatus(404)
    }
    res.status(200).json(dados[id - 1])
})

app.get("/test", (req, res) => res.sendStatus(200))

app.patch('/api/colecao/:id', (req, res) => {
    const id = req.params
    if (id == undefined) {
        res.sendStatus(404)
    }
    dados[id - 1] = id.req.body
    res.status(200)
})

app.post('/api/colecao', (req, res) => {
    const coisa = req.body
    const objeto = { coisa, id: dados.length + 1 }

    if (dados.id == objeto.id)
        res.json("mamaco")

    dados.push(objeto)
    res.status(200).json(dados)

})