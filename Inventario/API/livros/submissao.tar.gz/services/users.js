async function findAllUsers() {
    const users = await getAllUsers()
    return users
}