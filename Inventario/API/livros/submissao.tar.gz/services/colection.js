async function obtemDaColecao(id) {
    const stuff = await getCollectionBy_id(id)
    delete stuff._id
    return stuff
}


