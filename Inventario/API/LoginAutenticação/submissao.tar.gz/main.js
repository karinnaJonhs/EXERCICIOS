const { request, response } = require('express');
const express = require('express')
const app = express()
const PORT = process.env.PORT ?? 3000

const { Calculadora } = require("./calculadora");
const calc = new Calculadora()
app.use(express.json())
// POST http://localhost:3000/op/potencia {"a": 3, "b": 3}

app.post('/op/potencia', (req, res) => {
    const { a, b } = req.body

    if (isNaN(Number(a)) || (b !== undefined && isNaN(Number(b)))) {
        res.status(400).json({ erro: "Argumentos Inválidos" })
        return
    }
    res.status(200).json(
        { calculadora: calc.potencia(a, b) }
    )
})
app.post('/op/somar', (req, res) => {
    const { a, b } = req.body

    if (isNaN(Number(a)) || (b !== undefined && isNaN(Number(b)))) {
        res.status(400).json({ erro: "Argumentos Inválidos" })
        return
    }
    res.status(200).json(
        { calculadora: calc.somar(a, b) }
    )
})
app.post('/op/subtrair', (req, res) => {
    const { a, b } = req.body

    if (isNaN(Number(a)) || (b !== undefined && isNaN(Number(b)))) {
        res.status(400).json({ erro: "Argumentos Inválidos" })
        return
    }
    res.status(200).json(
        { calculadora: calc.subtrair(a, b) }
    )
})
app.post('/op/multiplicar', (req, res) => {
    const { a, b } = req.body

    if (isNaN(Number(a)) || (b !== undefined && isNaN(Number(b)))) {
        res.status(400).json({ erro: "Argumentos Inválidos" })
        return
    }
    res.status(200).json(
        { calculadora: calc.multiplicar(a, b) }
    )
})
app.post('/op/dividir', (req, res) => {
    const { a, b } = req.body

    if (isNaN(Number(a)) || (b !== undefined && isNaN(Number(b)))) {
        res.status(400).json({ erro: "Argumentos Inválidos" })
        return
    }
    res.status(200).json(
        { calculadora: calc.dividir(a, b) }
    )
})

app.post('/repetir', (req, res) => {
    res.status(200).json({ calculadora: calc.repetir(req.body.num).toJSON() })
    return
})

app.delete('/', (req, res) => {
    res.status(200).json({ calculadora: calc.limparHistorico().toJSON() })
    return
})

app.get('/ultimo-Resultado', (req, res) => {
    res.status(200).json({ ultimoResultado: calc.obterResultado().toString() })
    return
})

app.get('/', (req, res) => {
    res.status(200).json({ calculadora: calc })
    return
})


app.listen(PORT, () => {
    console.log(`À escuta em http://localhost:${PORT}`)
})