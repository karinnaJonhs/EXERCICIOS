const express = require('express')
const app = express()
app.use(express.json())
app.listen(3030, () => {
    console.log("À escuta em https://localhost:3030")
})
let animais = [
    /*
    {
        name: string,
        birthday: string,
        id: string (sequencial)
    }
    */
]

app.post('/api/animal', (req, res) => {
    const { name, birthday } = req.body
    const animal = { name, birthday, id: animais.length + 1 }
    animais.push(animal)
    res.status(200).json(animal)
})

app.get('/api/animal', (req, res) => {
    res.status(200).json(animais)
})

app.get('/api/animal/:id', (req, res) => {
    const { id } = req.params

    if (id == undefined) {
        res.sendStatus(404)
    }
    res.status(200).json(animais[id - 1])
    // res.status(200).json(animais.find(animal => animal.id === id)

})