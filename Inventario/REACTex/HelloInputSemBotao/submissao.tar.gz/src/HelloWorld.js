export default function HelloWorld({ name }) {

    return (

        <div>Hello, {name !== undefined ? `${name}.` : "stranger."}</div>
    )
}