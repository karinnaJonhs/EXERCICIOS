const Lista = (props) => {
    return (
        <div>
            {props.titulo && <h1>{props.titulo}</h1>}

            <ul>
                {props.itens.map((item, i) => (
                    <li key={i}>{item}</li>
                ))}
            </ul>
        </div>
    )
}

export default Lista