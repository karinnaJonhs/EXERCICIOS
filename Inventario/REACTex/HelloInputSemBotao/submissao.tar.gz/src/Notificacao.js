function Notificacao(props) {
    return (
        <div style={{}}>
            <div style={{ backgroundColor: "#d3d3d3", width: "50%", borderRadius: "10px", textAlign: "left", padding: "0.3px", marginLeft: "10px", position: "absolute" }}>

                <p><b>{
                    props.source
                }</b></p>
                <p>{
                    props.content
                }</p>

            </div>
            <div style={{ backgroundColor: props.color, borderRadius: "10px", width: "50%", height: "84px", position: "relative", zIndex: "-1" }}>


            </div>



        </div>

    )
}

export default Notificacao