// import { json } from "express";
// import { useState } from "react";
// import { useEffect } from 'react';

// function Lista({ animais }) {
//     const [lista, setLista] = useState([])

//     const handleSelection = (id) => {
//         setLista(prevLista => {
//             if (prevLista.includes(id)) {
//                 return {
//                     id: lista.id[id - 1],
//                     nome: lista.nome[id - 1]
//                 }
//             } else {
//                 return [...prevLista, id]
//             }
//         })
//     }

//     const fetchData = async () => {
//         const res = await fetch("/api/animal", {
//             method: "GET"
//         })
//         const body = await res.json()

//         setLista(body.animais)
//     }

//     useEffect(() => {
//         //Código executado quando o componente monta
//         fetchData()
//     }, [])


//     return (
//         <div>
//             Lista
//             {
//                 lista.map(animal => (
//                     <div
//                         key={animal.id}
//                         onClick={() => handleSelection(animal.id)}>
//                         <span>{animal.id}</span>
//                         <span>{animal.nome}</span>
//                         {
//                             selected.includes(animal.id) && (<div>
//                                 <p>{animal.birthday}</p>
//                             </div>)
//                         }
//                     </div>
//                 ))
//             }
//         </div>
//     )


// }




// export function Express() {
//     const [visivel, setVisivel] = useState(true)

//     const [animal, setAnimal] = useState({ nome: '', aniversario: '' })




//     return (
//         <div>

//             <input
//                 type="text"
//                 value={animal.nome}
//                 onChange={e =>
//                     setAnimal(prevAnimal => ({
//                         ...prevAnimal,
//                         nome: e.target.value
//                     }))} />
//             <input
//                 type="date"
//                 value={animal.aniversario}
//                 onChange={e =>
//                     setAnimal(prevAnimal => ({
//                         ...prevAnimal,
//                         aniversario: e.target.value
//                     }))} />

//             <button
//                 onClick={async () => {
//                     const res = await fetch(
//                         '/api/animal', {
//                         method: 'POST',
//                         headers: {
//                             "Content-Type": "application/json"
//                         },
//                         body: JSON.stringify({
//                             name: animal.nome,
//                             birthday: animal.aniversario
//                         })
//                     })

//                     const body = await res.json()

//                     fetchData()

//                     console.log(res.status)


//                 }}>
//                 Criar Animal
//             </button>


//             <div>
//                 {
//                     visivel
//                         ?
//                         <button onClick={() => setVisivel(prevVisivel => !prevVisivel)}>Mostrar Lista de Animais Criados</button>

//                         :

//                         <div>
//                             <button onClick={() => setVisivel(prevVisivel => !prevVisivel)}>Ocultar Lista Animais Criados</button>
//                             <div>

//                                 <Lista />

//                             </div>
//                         </div>
//                 }



//             </div>

//         </div>
//     )
// }
