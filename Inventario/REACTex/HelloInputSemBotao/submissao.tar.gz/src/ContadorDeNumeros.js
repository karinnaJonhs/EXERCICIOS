import { useState } from "react"

function GeradorDeNumeros() {
    const [randoN, setRandon] = useState("Clique em Gerar")

    const gerarNumero = () => {
        const aleatorio = Math.floor(Math.random() * 100) + 1
        setRandon(aleatorio)
    }

    return (
        <div>
            <h1>Gerador de números</h1>
            <p>{randoN}</p>
            <button onClick={() => gerarNumero()}>Gerar</button>
        </div>
    )


}

export default GeradorDeNumeros