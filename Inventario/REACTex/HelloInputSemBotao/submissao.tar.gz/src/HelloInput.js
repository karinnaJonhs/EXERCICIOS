import { useState } from "react"

export default function HelloInput() {
    //campo de texto
    //paragrafo
    //botao

    const [state, setState] = useState("")
    // const [visivel, setVisivel] = useState(true)


    // return (
    //     <div>
    //         <input type="text" value={state} onChange={(e) => setState(e.target.value)} />
    //         {
    //             visivel
    //                 ? <button
    //                     onClick={() =>
    //                         setVisivel(prevVisivel => !prevVisivel)}>
    //                     Apresentar
    //                 </button>
    //                 : <p>Hello, {state}!</p>
    //         }





    //     </div>
    // )


    return (
        <div>
            <input type="text" value={state} onChange={(e) => setState(e.target.value)} />
            {


                <p>Hello, {state}!</p>
            }

        </div>
    )
}
