import './App.css';

import HelloInput from './HelloInput';

function App() {


  return (

    <div>

      <HelloInput />

    </div >
  );
}

export default App;
