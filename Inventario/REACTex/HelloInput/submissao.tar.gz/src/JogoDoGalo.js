import App from "./App"
import { useState, version } from "react"

import { jogo, verificarFimDoJogo, adicionarJogada, obterLinhas, verificarVencedor, obterJogadasPossiveis } from "./jogo-do-galo"


function Final({ jogo, resetGame }) {
    // return (
    //     <div>
    //         <h2 className="winnerMensagem">
    //             <span data-testid="gameover">Jogo Terminado!</span>
    //             <p data-testid="winner">
    //                 {verificarVencedor(jogo) !== undefined ?
    //                     <span> Vencedor: <span className="winner">{verificarVencedor(jogo)}</span> </span>
    //                     : <span>EMPATE</span>}
    //             </p>
    //         </h2>
    //     </div>)

    return (
        <div className="winnerMensagem">
            <p data-testid="gameover">Jogo Terminado!</p>
            <p>{verificarVencedor(jogo) !== undefined
                ? <span>
                    Vencedor: <span className="winner" data-testid="winner">{verificarVencedor(jogo)}
                    </span>
                </span>
                :
                <span >
                    EMPATE
                </span>

            }</p>
        </div>
    )
}
export function JogoDoGalo() {
    const [state, setState] = useState(jogo)
    const fim = verificarFimDoJogo(state)
    const resetGame = () => {
        setState(jogo)
    }


    return (
        <main>
            <div className="titulo"><h1>LUA DO GALO</h1></div>


            <div className="board">
                {state.tabuleiro.map((linha, i) => (
                    <div key={`${i}`} className="row">
                        {
                            linha.map((casa, j) => (
                                <div
                                    key={`${i}${j}`}
                                    className="cell"
                                    data-testid={`l${i}c${j}`}
                                    onClick={() => setState(jogo =>
                                        adicionarJogada(
                                            jogo,
                                            jogo.jogadorAtual,
                                            i,
                                            j))}>
                                    {casa !== "_" && casa}
                                </div>))}
                    </div>
                ))}


            </div>
            <div className="footer">
                {!fim && <p className="atual">Jogador Atual: <span data-testid="turn">{state.jogadorAtual}</span></p>}
                {fim && <Final jogo={state} resetGame={resetGame} ></Final>}
                <button className="botao" data-testid="restart" onClick={resetGame}>NOVAMENTE</button>
            </div>
        </main>
    );

}


