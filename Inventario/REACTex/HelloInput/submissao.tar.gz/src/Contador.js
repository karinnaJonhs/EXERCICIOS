import App from "./App"
import { useState } from "react"

function Contador() {

    const [i, setContador] = useState(0)

    const descrementar = () => {
        setContador((previContador) => previContador - 1)
    }
    const incrementar = () => {
        setContador((previContador) => previContador + 1)
    }

    ab


    return (

        <div role="main">
            <button onClick={descrementar} disabled={i <= 0}>-</button>
            <p>{i}</p>
            <button onClick={incrementar}>+</button>
        </div>)

}

export default Contador