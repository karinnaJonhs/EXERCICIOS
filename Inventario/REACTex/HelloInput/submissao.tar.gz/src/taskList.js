import React from "react";
import { useState } from "react";
import App from "./App";
import './App.css';

/*
    []Criar uma lista a partir de um array
    []Para mapear arrays é preciso recorrer ao .map
    []Cada elemento do a

    [] Criar um state para guardar a própria lista (array)
    [] Criar um state para guardar a própria 

    TASKS -> string[]



    TASKS -> TASK[]

    TASK -> {
        content: string
        don: boolean
    }

*/

export function TaskList({ tasks }) {

    const [state, setState] = useState(tasks.map(task => ({ content: task, done: false })))

    const handleChecked = (index) => {
        setState((prevState) => {
            return prevState.map((task, i) => i === index ? ({ ...task, done: !task.done }) : task)
        })
    }



    return (

        <div>

            <ul>
                {
                    state.map((task, i) => (
                        <div key={`${task.content}${i}`}>
                            <li><input onClick={() => handleChecked(i)} type={"checkbox"} />
                                <span className={task.done ? App.done : ""}>{task.content}</span>
                            </li>

                        </div>
                    ))
                }

            </ul>

            <button onClick={() => console.log(state.map(task => task.done))}>Testar</button>

        </div>

    )
}
