function adicionarJogada(jogo, jogador, linha, coluna) {
    if (verificarFimDoJogo(jogo)) return jogo
    return {
        ...jogo,
        tabuleiro: jogo.tabuleiro
            .map((l, i) => l.map((p, j) =>
                i === linha && j === coluna && p === '_'
                    ? jogador
                    : p)),
        jogadorAtual: jogo.tabuleiro[linha][coluna] === '_'
            ? jogo.jogadorAtual === 'X' ? 'O' : 'X'
            : jogo.jogadorAtual
    }
}

function obterJogadasPossiveis(jogo) {
    return jogo.tabuleiro
        .reduce((jogadas, linha, i) =>
            jogadas.concat(
                linha.reduce((colunas, pos, j) =>
                    pos === '_'
                        ? colunas.concat(j)
                        : colunas
                    , [])
                    .map((j) => ({ linha: i, coluna: j }))
            ), [])
}

function verificarVencedor(jogo) {
    const linhas = obterLinhas(jogo)
    console.log(linhas)
    return linhas.includes("XXX")
        ? "X"
        : linhas.includes("OOO")
            ? "O"
            : undefined
}

function obterLinhas(jogo) {
    const tabuleiro = jogo.tabuleiro
    const linhas = jogo.tabuleiro.map(t => t.join(''))
    const colunas = []
    const diagonais = ["", ""]
    for (let i = 0; i < tabuleiro.length; i++) {
        diagonais[0] += tabuleiro[i][i]
        diagonais[1] += tabuleiro[i][tabuleiro.length - 1 - i]
        colunas.push(jogo.tabuleiro.map(l => l[i]).join(''))
    }
    return linhas.concat(colunas).concat(diagonais)
}

function verificarFimDoJogo(jogo) {
    return Boolean(verificarVencedor(jogo)) || obterJogadasPossiveis(jogo).length === 0
}

const jogo = {
    tabuleiro: [
        ["_", "_", "_"],
        ["_", "_", "_"],
        ["_", "_", "_"],
    ],
    jogadorAtual: "X"
}

export { jogo, verificarFimDoJogo, adicionarJogada, obterLinhas, verificarVencedor, obterJogadasPossiveis }
