import React from "react";
import { useState } from "react";

export function Form() {
    const [state, setState] = useState("")

    return (

        <div>
            <input onChange={(e) => setState(e.target.value)}></input>
            <button onClick={() => console.log(state)}>ESTADO</button>
        </div>
    )

}


export default Form




