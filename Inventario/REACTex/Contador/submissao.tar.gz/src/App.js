import './App.css';
import Notificacao from './Notificacao';
import { Form } from './Form';
import HelloWorld from './HelloWorld';
import Checkbox from './Checkbox';
import HelloInput from './HelloInput';
import Contador from './Contador';

function App() {



  // const [tasks, setTasks] = useState([
  //   { texto: "Abcdário", concluido: false },
  //   { texto: "Geraldo", concluido: true },
  //   { texto: "Pistache", concluido: true }
  // ])
  return (

    <div>

      <Contador></Contador>
      {/*
      <HelloInput></HelloInput>
      
      <HelloWorld name={"joorge"} />

      <Checkbox />



      <TaskList tasks={[
        "Acordar",
        "Escovar os dentes",
        "Cantar o hino comunista",
        "Cancelar alguém no twitter",
        "Publicar vídeos sobre Setembro Amarelo",
        "Comer sopa"
      ]}>


      </TaskList>
      */}


      {/* <Notificacao
        color="#ff0056"
        content="Paga já dinheiro aqui"
        source="Pingo Doce"
      ></Notificacao> */}

      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
    </div >
  );
}

export default App;
