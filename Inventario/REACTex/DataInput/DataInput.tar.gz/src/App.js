import logo from './logo.svg';
import './App.css';
import DataInput from './DataInput';


function App() {
  return (
    <div className="App">
      < DataInput />
    </div>
  );
}

export default App;
