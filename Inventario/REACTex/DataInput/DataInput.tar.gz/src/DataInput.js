import { useState } from "react"

export default function DataInput() {
    // let condition=true
    const [condition, setCondition] = useState(false)
    const [dateInput, setDateInput] = useState("")

    return (
        <div>
            <h3>Insere a tua data de nascimento.</h3>
            <div role="content">
                {
                    condition
                        ? <p>Nasceste no dia {dateInput.split('-')[2]} do {dateInput.split('-')[1]} de {dateInput.split('-')[0]}!</p>
                        : <input value={dateInput} onChange={(event) => setDateInput(event.target.value)} type="date"></input>
                }
              
            </div>
              <button onClick={() => setCondition((prevCondition) => !prevCondition)}>{
                    condition ? "Alterar" : "Mostrar"
                }
                </button>
        </div>
    )
}


